import { Title } from "../../components/shared/Title"

export const MapPage = () => {
  return (
    <div>
      <Title text="Mapa" />

        <img src="https://cdn.memegenerator.es/descargar/1379109" alt="" />

    </div>
  )
}
