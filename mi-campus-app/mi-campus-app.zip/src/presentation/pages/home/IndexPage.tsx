import { Title } from "../../components/shared/Title"

export const IndexPage = () => {
  return (
    <div>
      <Title text="Incio " />

        <img src="https://cdn.memegenerator.es/descargar/1379109" alt="" />

    </div>
  )
}