export interface LoginResponse {
    email: string;
    token: string;
}