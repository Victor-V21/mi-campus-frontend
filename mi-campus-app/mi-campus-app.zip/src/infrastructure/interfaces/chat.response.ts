export interface ChatResponse {
    response: string;
}