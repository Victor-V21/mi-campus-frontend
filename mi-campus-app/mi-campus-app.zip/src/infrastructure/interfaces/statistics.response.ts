export interface Statistics {
  estudiantesCount: number;
  eventosCount :   number;
  chatsCount: number;
}
