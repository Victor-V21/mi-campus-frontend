export interface CampusesResponse {
    id: string;
    name: string;
    description: string;
    location: string;
    isEnabled?: boolean
}
