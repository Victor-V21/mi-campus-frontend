
export type Role = "SYS_ADMIN";
