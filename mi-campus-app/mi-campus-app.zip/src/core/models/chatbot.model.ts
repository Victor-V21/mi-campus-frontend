export interface ChatBotPrompt {
    prompt: string;
}
