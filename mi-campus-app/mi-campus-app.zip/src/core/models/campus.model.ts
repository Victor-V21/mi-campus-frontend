export interface CampusModel {
    name: string;
    location: string;
    description: string;
    isEnabled?: boolean;
}
