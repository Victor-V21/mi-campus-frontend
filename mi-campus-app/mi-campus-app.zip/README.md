# Mi Campus app

En este repositorio se presenta el proyecto de "mi campus"

## Instalación

### Desde la consola:

Actualizar los paquetes de React
```
npm install
```
Instalar TailWind
```
npm install tailwindcss @tailwindcss/vite
```
Instalar Bootstrap
```
npm install react-bootstrap bootstrap
```